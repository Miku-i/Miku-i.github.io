public class ClassList {
    public int classId;
    public String className;

    public ClassList(int classId, String className) {
        this.classId = classId;
        this.className = className;
    }
}
